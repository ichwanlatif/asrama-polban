<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approval Resign Asrama</title>
</head>
<body>
    <h1>APPROVAL RESIGN ASRAMA</h1>
    <h4>Resign pada:</h4>
    <p>Tanggal: {{$details['tanggal_resign']}}</p>
    <p>Alasan: {{$details['keterangan_resign']}}</p>
    <p>Suhu Badan: {{$details['suhu_badan']}}</p>
    <p>Kondisi Kesehatan: {{$details['kondisi_kesehatan']}}</p>
    <p>Kendaraan Yang di Bawa: {{$details['jenis_kendaraan']}}</p>
    <br>
    <h4>TELAH DI APPROVAL</h4>


    <p>Segera lihat hasil approval dengan mengklik <a href="https://asrama-polban.herokuapp.com/#/riwayat-perizinan">link ini.</a></p>

</body>
</html>